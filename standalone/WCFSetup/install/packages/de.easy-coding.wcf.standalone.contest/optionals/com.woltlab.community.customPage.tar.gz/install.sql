DROP TABLE IF EXISTS wcf1_costumpage;
CREATE TABLE wcf1_custompage (
  pageID int(10) unsigned NOT NULL auto_increment,
  name varchar(255) NOT NULL,
  description text NOT NULL,
  templateName varchar(255) NOT NULL,
  icon varchar(255) NOT NULL,
  permission varchar(255) NOT NULL,
  wrapperID int(10) unsigned NOT NULL,
  isActive tinyint(1) unsigned NOT NULL,
  content longtext NOT NULL,
  menuItemID int(10) unsigned NOT NULL,
  parentPageID int(10) unsigned NOT NULL,
  preParentID INT( 10 ) NOT NULL,
  PRIMARY KEY  (pageID)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS wcf1_costumpage_wrapper;
CREATE TABLE wcf1_custompage_wrapper (
  wrapperID int(10) unsigned NOT NULL auto_increment,
  packageID int(10) unsigned NOT NULL,
  templateName varchar(255) NOT NULL,
  PRIMARY KEY  (wrapperID)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;
