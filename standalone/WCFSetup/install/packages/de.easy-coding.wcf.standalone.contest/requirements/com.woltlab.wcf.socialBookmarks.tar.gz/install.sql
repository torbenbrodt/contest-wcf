-- create table
DROP TABLE IF EXISTS wcf1_social_bookmark_provider;
CREATE TABLE wcf1_social_bookmark_provider (
	providerID INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	title VARCHAR(255) NOT NULL DEFAULT '',
	url VARCHAR(255) NOT NULL DEFAULT '',
	providerImage VARCHAR(255) NOT NULL DEFAULT '',
	showOrder SMALLINT(5) NOT NULL DEFAULT 0,
	enabled TINYINT(1) NOT NULL DEFAULT 1,
	KEY (enabled)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- insert default values
INSERT INTO	wcf1_social_bookmark_provider
		(title, url, providerImage, showOrder, enabled)
VALUES		('Facebook', 'http://www.facebook.com/sharer.php?u=%s&t=%s', 'icon/socialBookmarks/facebookM.png', 1, 1),
		('Twitter', 'http://twitter.com/?status=%2$s - %1$s', 'icon/socialBookmarks/twitterM.png', 2, 1),
		('digg', 'http://digg.com/submit?phase=2&url=%s&title=%s', 'icon/socialBookmarks/diggM.png', 3, 1),
		('MySpace', 'http://www.myspace.com/Modules/PostTo/Pages/?u=%s', 'icon/socialBookmarks/mySpaceM.png', 4, 1),
		('delicious', 'http://delicious.com/save?v=5&noui&jump=close&url=%s&title=%s', 'icon/socialBookmarks/deliciousM.png', 5, 1),
		('Google', 'http://www.google.com/bookmarks/mark?op=add&hl=en&bkmk=%s&title=%s', 'icon/socialBookmarks/googleM.png', 6, 1),
		('reddit', 'http://de.reddit.com/submit?url=%s', 'icon/socialBookmarks/redditM.png', 7, 1),
		('Mister Wong', 'http://www.mister-wong.de/index.php?action=addurl&bm_url=%s&bm_description=%s', 'icon/socialBookmarks/misterWongM.png', 8, 0),
		('StumbleUpon', 'http://www.stumbleupon.com/submit?url=%s&title=%s', 'icon/socialBookmarks/stumbleUponM.png', 9, 0),
		('Yahoo!', 'http://de.myweb2.search.yahoo.com/myresults/bookmarklet?t=%s&u=%s', 'icon/socialBookmarks/yahooM.png', 10, 0),
		('LinkedIn', 'http://www.linkedin.com/shareArticle?mini=true&url=%s&title=%s', 'icon/socialBookmarks/linkedInM.png', 11, 0)
		