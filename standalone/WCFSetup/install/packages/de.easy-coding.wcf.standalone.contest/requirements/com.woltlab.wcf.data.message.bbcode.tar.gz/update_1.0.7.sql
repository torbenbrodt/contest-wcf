@ALTER TABLE wcf1_bbcode ADD disabled tinyint(1) unsigned NOT NULL default 0;
@ALTER TABLE wcf1_smiley ADD smileyCategoryID INT(10) NOT NULL DEFAULT 0;
ALTER TABLE wcf1_smiley ADD KEY (smileyCategoryID);

DROP TABLE IF EXISTS wcf1_smiley_category;
CREATE TABLE wcf1_smiley_category (
	smileyCategoryID INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	title VARCHAR(255) NOT NULL DEFAULT '',
	showOrder MEDIUMINT(5) NOT NULL DEFAULT 0,
	disabled TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;