DROP TABLE IF EXISTS wcf1_page_menu_item;
CREATE TABLE wcf1_page_menu_item (
	menuItemID INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	packageID INT(10) NOT NULL DEFAULT 0,
	menuItem VARCHAR(255) NOT NULL DEFAULT '',
	menuItemLink VARCHAR(255) NOT NULL DEFAULT '',
	menuItemIconS VARCHAR(255) NOT NULL DEFAULT '',	
	menuItemIconM VARCHAR(255) NOT NULL DEFAULT '',
	menuPosition ENUM('header', 'footer') NOT NULL DEFAULT 'header',
	showOrder INT(10) NOT NULL DEFAULT 0,
	permissions TEXT NULL,
	options TEXT NULL,
	isDisabled TINYINT(1) NOT NULL DEFAULT 0,
	UNIQUE KEY (packageID, menuItem)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- copy data
INSERT INTO	wcf1_page_menu_item
			(menuItemID, packageID, menuItem, menuItemLink, menuItemIconM, showOrder, permissions)
SELECT		menuItemID, packageID, menuItem, menuItemLink, menuItemIcon, showOrder, permissions
FROM		wcf1_header_menu_item;

-- drop obsolete table
DROP TABLE IF EXISTS wcf1_header_menu_item;

DELETE FROM wcf1_package_installation_plugin WHERE pluginName = 'HeaderMenuPackageInstallationPlugin';