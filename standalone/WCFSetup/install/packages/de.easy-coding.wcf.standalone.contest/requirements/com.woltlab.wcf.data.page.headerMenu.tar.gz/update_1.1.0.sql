@ALTER TABLE wcf1_page_menu_item ADD isDisabled TINYINT(1) NOT NULL DEFAULT 0;

DELETE FROM wcf1_package_installation_plugin WHERE pluginName = 'HeaderMenuPackageInstallationPlugin';