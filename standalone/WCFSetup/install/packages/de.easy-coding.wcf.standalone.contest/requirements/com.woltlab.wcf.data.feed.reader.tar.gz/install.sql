DROP TABLE IF EXISTS wcf1_feed_source;
CREATE TABLE wcf1_feed_source (
	sourceID int(10) unsigned NOT NULL auto_increment,
	sourceName varchar(255) NOT NULL default '',
	sourceURL varchar(255) NOT NULL default '',
	packageID int(10) unsigned NOT NULL default 0,
	lastUpdate int(10) unsigned NOT NULL default 0,
	updateCycle int(10) unsigned NOT NULL default 0,
	PRIMARY KEY (sourceID),
	UNIQUE KEY (packageID, sourceName)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS wcf1_feed_entry;
CREATE TABLE wcf1_feed_entry (
	entryID int(10) unsigned NOT NULL auto_increment,
	sourceID int(10) unsigned NOT NULL default 0,
	title varchar(255) NOT NULL default '',
	author varchar(255) NOT NULL default '',
	link varchar(255) NOT NULL default '',
	guid varchar(255) NOT NULL default '',
	pubDate int(10) unsigned NOT NULL default 0,
	description mediumtext,
	PRIMARY KEY (entryID),
	UNIQUE KEY (sourceID, guid)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;