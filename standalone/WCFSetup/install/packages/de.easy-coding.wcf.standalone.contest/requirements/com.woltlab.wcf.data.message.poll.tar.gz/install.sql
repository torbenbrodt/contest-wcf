DROP TABLE IF EXISTS wcf1_poll;
CREATE TABLE wcf1_poll (
	pollID int(10) unsigned NOT NULL auto_increment,
	packageID int(10) unsigned NOT NULL default 0,
	messageID int(10) unsigned NOT NULL default 0,
	messageType varchar(255) NOT NULL default '',
	question varchar(255) NOT NULL default '',
	time int(10) unsigned NOT NULL default 0,
	endTime int(10) unsigned NOT NULL default 0,
	choiceCount tinyint(3) unsigned NOT NULL default 0,
	votes mediumint(7) unsigned NOT NULL default 0,
	votesNotChangeable tinyint(1) unsigned NOT NULL default 0,
	sortByResult tinyint(1) unsigned NOT NULL default 0,
	isPublic TINYINT(1) NOT NULL DEFAULT 0,
	PRIMARY KEY (pollID),
	KEY (messageID, messageType, packageID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS wcf1_poll_option;
CREATE TABLE wcf1_poll_option (
	pollOptionID int(10) unsigned NOT NULL auto_increment,
	pollID int(10) unsigned NOT NULL default 0,
	pollOption varchar(255) NOT NULL default '',
	votes mediumint(7) unsigned NOT NULL default 0,
	showOrder tinyint(3) unsigned NOT NULL default 0,
	PRIMARY KEY  (pollOptionID),
	KEY (pollID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS wcf1_poll_option_vote;
CREATE TABLE wcf1_poll_option_vote (
	pollID int(10) unsigned NOT NULL default 0,
	pollOptionID int(10) unsigned NOT NULL default 0,
	userID int(10) unsigned NOT NULL default 0,
	ipAddress varchar(15) NOT NULL default '',
	KEY (pollID, userID),
	KEY (pollID, ipAddress),
	KEY (pollOptionID, userID),
	KEY (pollOptionID, ipAddress)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS wcf1_poll_vote;
CREATE TABLE wcf1_poll_vote (
	pollID int(10) unsigned NOT NULL default 0,
	isChangeable tinyint(1) unsigned NOT NULL default 1,
	userID int(10) unsigned NOT NULL default 0,
	ipAddress varchar(15) NOT NULL default '',
	KEY (pollID, userID),
	KEY (pollID, ipAddress)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
