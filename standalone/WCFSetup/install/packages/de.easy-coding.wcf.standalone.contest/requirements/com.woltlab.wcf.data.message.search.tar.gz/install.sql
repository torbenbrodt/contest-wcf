DROP TABLE IF EXISTS wcf1_searchable_message_type;
CREATE TABLE wcf1_searchable_message_type (
	typeID int(10) unsigned NOT NULL auto_increment,
	typeName varchar(255) NOT NULL default '',
	classPath varchar(255) NOT NULL default '',
	packageID int(10) unsigned NOT NULL default 0,
	PRIMARY KEY  (typeID),
	UNIQUE KEY (packageID, typeName)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
