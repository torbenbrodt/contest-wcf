DROP TABLE IF EXISTS wcf1_help_item;
CREATE TABLE wcf1_help_item (
	helpItemID int(10) UNSIGNED NOT NULL auto_increment,
	packageID int(10) UNSIGNED NOT NULL DEFAULT 0,
	helpItem varchar(255) NOT NULL DEFAULT '',
	parentHelpItem varchar(255) NOT NULL DEFAULT '',
	refererPattern varchar(255) NOT NULL DEFAULT '',
	showOrder int(10) UNSIGNED NOT NULL DEFAULT 0,
	permissions TEXT NULL,
	options TEXT NULL,
	isDisabled TINYINT(1) NOT NULL DEFAULT 0,
	PRIMARY KEY (helpItemID),
	UNIQUE KEY (packageID, helpItem)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- new index for help search
ALTER TABLE wcf1_language_item ADD INDEX (languageID, languageCategoryID, packageID);