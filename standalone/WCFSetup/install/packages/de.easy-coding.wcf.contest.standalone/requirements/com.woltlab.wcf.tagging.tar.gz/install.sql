DROP TABLE IF EXISTS wcf1_tag;
CREATE TABLE wcf1_tag (
	tagID 					INT(10) 		NOT NULL AUTO_INCREMENT PRIMARY KEY,
	languageID				INT(10)			NOT NULL DEFAULT 0,
	name 					VARCHAR(255) 	NOT NULL DEFAULT '',
	UNIQUE KEY (languageID, name)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS wcf1_tag_taggable;
CREATE TABLE wcf1_tag_taggable (
	taggableID 				INT(10) 		NOT NULL AUTO_INCREMENT PRIMARY KEY,
	name 					VARCHAR(255) 	NOT NULL DEFAULT '',
	classPath 				VARCHAR(255) 	NOT NULL DEFAULT '',
	packageID		 		INT(10) 		NOT NULL DEFAULT 0,
	UNIQUE (name, packageID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS wcf1_tag_to_object;
CREATE TABLE wcf1_tag_to_object (
	objectID 				INT(10) 		NOT NULL DEFAULT 0,
	tagID					INT(10)			NOT NULL DEFAULT 0,
	taggableID				INT(10)			NOT NULL DEFAULT 0,
	time					INT(10)			NOT NULL DEFAULT 0,
	languageID				INT(10)			NOT NULL DEFAULT 0,
	PRIMARY KEY (taggableID, languageID, objectID, tagID),
	KEY (taggableID, languageID, tagID),
	KEY (tagID, taggableID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;