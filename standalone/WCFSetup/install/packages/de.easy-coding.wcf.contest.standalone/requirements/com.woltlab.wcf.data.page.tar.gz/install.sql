DROP TABLE IF EXISTS wcf1_page_location;
CREATE TABLE wcf1_page_location (
	locationID int(10) unsigned NOT NULL auto_increment,
	locationPattern varchar(255) NOT NULL default '',
	locationName varchar(255) NOT NULL default '',
	packageID int(10) NOT NULL default 0,
	classPath varchar(255) NOT NULL default '',
	PRIMARY KEY (locationID),
	UNIQUE KEY (packageID, locationName)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;