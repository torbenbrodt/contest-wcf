@ALTER TABLE wcf1_attachment CHANGE messageID containerID INT(10) NOT NULL DEFAULT 0;
@ALTER TABLE wcf1_attachment CHANGE messageType containerType VARCHAR(255) NOT NULL DEFAULT '';
@ALTER TABLE wcf1_attachment ADD width SMALLINT(5) NOT NULL DEFAULT 0;
@ALTER TABLE wcf1_attachment ADD height SMALLINT(5) NOT NULL DEFAULT 0;
@ALTER TABLE wcf1_attachment ADD thumbnailWidth SMALLINT(5) NOT NULL DEFAULT 0;
@ALTER TABLE wcf1_attachment ADD thumbnailHeight SMALLINT(5) NOT NULL DEFAULT 0;
@ALTER TABLE wcf1_attachment ADD showOrder SMALLINT(5) NOT NULL DEFAULT 0;
ALTER TABLE wcf1_attachment ADD KEY (userID, packageID);

DROP TABLE IF EXISTS wcf1_attachment_container_type;
CREATE TABLE wcf1_attachment_container_type (
	containerTypeID INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	packageID INT(10) NOT NULL,
	containerType VARCHAR(255) NOT NULL,
	isPrivate TINYINT(1) NOT NULL DEFAULT 0,
	url VARCHAR(255) NOT NULL DEFAULT '',
	UNIQUE KEY (packageID, containerType),
	KEY (isPrivate)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;