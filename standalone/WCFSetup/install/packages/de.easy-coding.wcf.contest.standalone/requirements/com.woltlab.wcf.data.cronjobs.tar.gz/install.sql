DROP TABLE IF EXISTS wcf1_cronjobs;
CREATE TABLE wcf1_cronjobs (
	cronjobID int(10) unsigned NOT NULL auto_increment,
	classPath varchar(255) NOT NULL default '',
	packageID int(10) unsigned NOT NULL default 0,
	description varchar(255) NOT NULL default '',
	startMinute varchar(255) NOT NULL default '*',
	startHour varchar(255) NOT NULL default '*',
	startDom varchar(255) NOT NULL default '*',
	startMonth varchar(255) NOT NULL default '*',
	startDow varchar(255) NOT NULL default '*',
	lastExec int(10) unsigned NOT NULL default 0,
	nextExec int(10) unsigned NOT NULL default 0,
	execMultiple TINYINT NOT NULL default 0,
	active TINYINT NOT NULL default 1,
	canBeEdited TINYINT NOT NULL default 1,
	canBeDisabled TINYINT NOT NULL default 1,
	PRIMARY KEY  (cronjobID),
	KEY (packageID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS wcf1_cronjobs_log;
CREATE TABLE wcf1_cronjobs_log (
	cronjobsLogID int(10) unsigned NOT NULL auto_increment,
	cronjobID int(10) unsigned NOT NULL default 0,
	execTime int(10) NOT NULL default 0,
	success TINYINT NOT NULL default 0,
	error TEXT,
	PRIMARY KEY  (cronjobsLogID),
	KEY (cronjobID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;