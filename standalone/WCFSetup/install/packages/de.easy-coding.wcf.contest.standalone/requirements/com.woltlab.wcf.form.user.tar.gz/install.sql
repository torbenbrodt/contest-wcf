ALTER TABLE wcf1_user ADD activationCode int(10) UNSIGNED NOT NULL default 0;
ALTER TABLE wcf1_user ADD registrationIpAddress varchar(15) NOT NULL default '';
ALTER TABLE wcf1_user ADD lastLostPasswordRequest int(10) UNSIGNED NOT NULL default 0;
ALTER TABLE wcf1_user ADD lostPasswordKey varchar(40) NOT NULL default '';
ALTER TABLE wcf1_user ADD newEmail varchar(255) NOT NULL default '';
ALTER TABLE wcf1_user ADD reactivationCode int(10) UNSIGNED NOT NULL default 0;
ALTER TABLE wcf1_user ADD oldUsername varchar(255) NOT NULL default '';
ALTER TABLE wcf1_user ADD lastUsernameChange int(10) UNSIGNED NOT NULL default 0;
ALTER TABLE wcf1_user ADD quitStarted int(10) UNSIGNED NOT NULL default 0;
ALTER TABLE wcf1_user ADD banned TINYINT(1) UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE wcf1_user ADD banReason mediumtext NULL;
ALTER TABLE wcf1_user ADD INDEX (activationCode);
ALTER TABLE wcf1_user ADD INDEX (registrationIpAddress, registrationDate);

DROP TABLE IF EXISTS wcf1_usercp_menu_item;
CREATE TABLE wcf1_usercp_menu_item (
  menuItemID int(10) unsigned NOT NULL auto_increment,
  packageID int(10) unsigned NOT NULL default '0',
  menuItem varchar(255) NOT NULL default '',
  parentMenuItem varchar(255) NOT NULL default '',
  menuItemLink varchar(255) NOT NULL default '',
  menuItemIcon varchar(255) NOT NULL default '',
  showOrder int(10) NOT NULL default '0',
  permissions text NULL,
  options TEXT NULL,
  PRIMARY KEY (menuItemID),
  UNIQUE KEY (menuItem,packageID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;